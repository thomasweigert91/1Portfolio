export const dbExperience = [
{
    year: "2022 - 2023",
    works: [
        {
            name: "Webdeveloper Bootcamp",
            company: "Neue Fische",
            desc: "I completed a three-month bootcamp at NeueFische to become a frontend developer.",
        }
    ]
    
},
{
    year: "2021 - 2022",
    works: [
        {
            name: "Real Estate Finance Specialist",

            company: "McMakler Finance",
            desc: "I have advised clients on all aspects of real estate financing and handled the application process together with them"   
        }
    ]
    
},
{
    year: "2015 - 2020",
    works: [
        {
            name: "Private Loan Specialist",

            company: "Finanzcheck, Smava",
            desc: "I have advised clients on obtaining a personal loan from a bank that is right for them."   
        }
    ]
    
}


]